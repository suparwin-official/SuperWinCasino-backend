const express = require("express");
const router = express.Router();
const adminAuth = require("../middleware/adminAuth");
const GameLog = require("../models/GameLog");

router.get("/", adminAuth, async (req,res)=>{
  res.json(await GameLog.find().sort({ createdAt:-1 }).limit(50));
});

module.exports = router;