const express = require("express");
const router = express.Router();
const {
  getAllUsers,
  updateUserBalance
} = require("../controllers/adminController");

router.get("/users", getAllUsers);
router.post("/balance", updateUserBalance);

module.exports = router;