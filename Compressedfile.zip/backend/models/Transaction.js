const mongoose = require("mongoose");

const TransactionSchema = new mongoose.Schema({
  user: { type: String, required: true },
  type: { type: String, required: true },        // bet, win, deposit, withdraw
  amount: { type: Number, required: true },
  status: { type: String, default: "pending" }, // pending, approved, rejected
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Transaction", TransactionSchema);