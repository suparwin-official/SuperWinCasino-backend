const mongoose = require("mongoose");

module.exports = mongoose.model("GameLog", new mongoose.Schema({
  user: String,
  bet: Number,
  win: Number,
  result: String,
  createdAt: { type: Date, default: Date.now }
}));