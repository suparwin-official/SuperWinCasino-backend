const mongoose = require("mongoose");

const SettingsSchema = new mongoose.Schema({
  rtp: { type: Number, default: 40 },  // RTP percentage (1–100)
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Settings", SettingsSchema);