const GameLog = require("../models/GameLog");

await GameLog.create({
  user: user.username,
  bet,
  win: winAmount,
  result: win ? "WIN" : "LOSE"
});