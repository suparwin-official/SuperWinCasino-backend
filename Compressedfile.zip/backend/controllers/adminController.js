const User = require("../models/User");

exports.getAllUsers = async (req, res) => {
  const users = await User.find({}, "-password");
  res.json(users);
};

exports.updateUserBalance = async (req, res) => {
  const { userId, amount } = req.body;

  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ msg: "User not found" });

  user.balance += Number(amount);
  await user.save();

  res.json({
    msg: "Balance updated",
    user
  });
};